class User < ApplicationRecord

end