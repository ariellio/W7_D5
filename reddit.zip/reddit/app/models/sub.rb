class Sub < ApplicationRecord
has_one :moderator,
    foreign_key: :moderator_id,
    class_name: :User

end