class SessionsController < ApplicationController
    
end