class PostsController < ApplicationController
    def show
        
    end

    def new

    end

    def create
        
    end

    def update

    end

    def edit

    end

    def destroy

    end
end