class SubsController < ApplicationController

    def create
    end

    def index
    end

    def show
    end

    def new
    end

    def edit
    end

    def update
    end

end